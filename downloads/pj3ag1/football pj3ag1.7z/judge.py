# pip install pyzmq cbor keyboard
from zmqRemoteApi import RemoteAPIClient
from zmqRemoteApi_IPv6 import RemoteAPIClient
import keyboard

client = RemoteAPIClient('localhost', 19997)

print('Program started')
sim = client.getObject('sim')
    
size = [0.1, 0.1, 0.1]
position = [0, 0, 0.5]
options = 8
 
cuboid = sim.createPureShape(0, 8, size, 1, None)
sim.setObjectPosition(cuboid, -1, position)

sim.startSimulation()
print('Simulation started')



